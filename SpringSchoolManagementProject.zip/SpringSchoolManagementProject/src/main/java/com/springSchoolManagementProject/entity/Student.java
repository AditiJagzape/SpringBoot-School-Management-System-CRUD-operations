package com.springSchoolManagementProject.entity;


import jakarta.persistence.*;

@Entity
    @Table(name ="Student")
    public class Student {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @Column(name ="name")
        private String name;

        @Column(name="age")
        private int age;
        @Column(name="grade")
        private String grade;
        @Column(name="address")
        private String address;
        @Column(name="email")
        private String email;

        public Long getID() {
            return id;
        }

        public void setID(Long id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {name = name; }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            age = age;
        }

        public String getGrade() {
            return grade;
        }

        public void setGrade(String grade) {
            grade = grade;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            address = address;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            email = email;
        }

        public Student(Long id, String name, int age, String grade, String address, String email) {
            this.id = id;
            this.name = name;
            this.age = age;
            this.grade = grade;
            this.address = address;
            email = email;
        }

        public Student() {
        }

        @Override
        public String toString() {
            return "Student{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    ", age=" + age +
                    ", grade='" + grade + '\'' +
                    ", address='" + address + '\'' +
                    ", Email='" + email + '\'' +
                    '}';
        }
    }
