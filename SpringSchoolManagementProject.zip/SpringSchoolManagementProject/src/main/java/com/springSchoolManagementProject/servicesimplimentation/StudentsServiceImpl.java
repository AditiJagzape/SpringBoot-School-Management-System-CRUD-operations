package com.springSchoolManagementProject.servicesimplimentation;

import com.springSchoolManagementProject.entity.Student;
import com.springSchoolManagementProject.repository.StudentRepo;
import com.springSchoolManagementProject.services.StudentServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


    @Service
    public class StudentsServiceImpl implements StudentServices {
        private StudentRepo studentRepo;

        @Autowired
        public StudentsServiceImpl(StudentRepo studentRepo) {
            this.studentRepo = studentRepo;
        }


        @Override
        public Student save(Student student) {
            return studentRepo.save(student);
        }

        @Override
        public Student getStudentById(Long id) {
            return studentRepo.findById(id).orElse(null);
        }

    }