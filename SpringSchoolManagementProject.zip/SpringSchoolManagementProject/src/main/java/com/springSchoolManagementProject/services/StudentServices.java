package com.springSchoolManagementProject.services;

import com.springSchoolManagementProject.entity.Student;
import org.springframework.stereotype.Service;


    @Service
    public interface StudentServices {

       // Student createStudent(Student student);

        Student save(Student student);

        Student getStudentById(Long id);
    }


