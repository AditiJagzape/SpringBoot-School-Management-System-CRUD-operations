package com.springSchoolManagementProject.controller;
import com.springSchoolManagementProject.services.StudentServices;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.springSchoolManagementProject.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class StudentController {

    private StudentServices studentService;

    @Autowired
    public StudentController(StudentServices studentService) {
        this.studentService = studentService;
    }

    @PostMapping("/student")
    public Student addStudent(@RequestBody Student student) {
        return studentService.save(student);
    }

    @GetMapping("/student/{id}")
    public Student getStudent(@PathVariable Long id) {
        return studentService.getStudentById(id);
    }

}




