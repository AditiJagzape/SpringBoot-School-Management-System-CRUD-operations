package com.springSchoolManagementProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSchoolManagementProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSchoolManagementProjectApplication.class, args);
	}

}
